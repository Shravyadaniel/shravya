#include <stdio.h>
int main()
{
    printf("the value is: %d\n", sizeof(char));
    printf("the value is: %d\n", sizeof(int));
    printf("the value is: %d\n", sizeof(float));
    printf("the value is: %d", sizeof(double));
    return 0;
}