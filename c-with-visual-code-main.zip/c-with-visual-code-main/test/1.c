// C program to illustrate If statement 
#include <stdio.h> 

int main() 
{ 
	int i = 10;
    int b;
    printf("plz enter an value:");
    scanf("%d",&b); 

	if (i > b) 
    { 
		printf("10 is greater than input"); 
	} 
else
	printf("I am Not in if"); 
}
