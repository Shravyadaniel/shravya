#include <stdio.h>
int main()
{
int a=10;
int *ptr;
printf("%d",*ptr);
return 0;
}