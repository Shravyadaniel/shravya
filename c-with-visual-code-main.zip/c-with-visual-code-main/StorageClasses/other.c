int a = 10;
