#include <stdio.h>
extern int a;
int main()
{
    printf("%d \n, a");
    return 0;
}