// C program to find the maximum number out of the three
// given numbers using if-else statement
#include <stdio.h>

int main()
{
    int A, B, C;

    printf("Enter the numbers A, B and C: ");
    scanf("%d %d %d", &A, &B, &C);
    // finding max using compound expressions
    if (A >= B && A >= C)
        printf("%d is the largest number.", A);

    else if (B >= A && B >= C)
        printf("%d is the largest number.", B);

    else
        printf("%d is the largest number.", C);

   
}
