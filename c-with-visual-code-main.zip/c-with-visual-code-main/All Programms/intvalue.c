// C Program to Print Integer value
#include <stdio.h>

// Driver code
int main()
{
	// Declaring integer
	int a = 143621;

	// Printing values
	printf("Printing Integer value %d", a);
	return 0;
}
