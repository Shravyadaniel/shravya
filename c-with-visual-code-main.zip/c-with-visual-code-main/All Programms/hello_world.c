// Simple C program to display "Hello World"

// Header file for input output functions
#include <stdio.h>

// main function - where the execution of program begins
int main()
{

	printf("Hello World");

	return 0;
}
