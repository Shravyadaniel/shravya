// C program to print ASCII Value of Character 
#include <stdio.h> 
 
int main() 
{ 
	char c = 'v'; 
 
	printf("The ASCII value of %c is %d", c, c); 
	return 0; 
}
