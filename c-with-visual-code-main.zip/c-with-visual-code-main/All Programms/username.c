// C program to demonstrate printing of 
// our own name using printf() 
#include <stdio.h> 

int main() 
{ 
	// print name 
	printf("Name : My Name is Vegi"); 
	return 0; 
}
